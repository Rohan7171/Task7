import java.util.ArrayList;
import java.util.Iterator;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;



import java.util.Map;
import matrix.db.Context;
import matrix.util.StringList;


public class TyreTable_mxJPO {
	
	

	public TyreTable_mxJPO()throws Exception {
		
	}	
	
	public TyreTable_mxJPO(Context context)throws Exception {
		

	}
	
	public TyreTable_mxJPO(Context context, String[] args)throws Exception {
		
	
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	
	public MapList getAllTyres(Context context,String args[]) throws Exception
	{
	
		StringList objField = new StringList(5); // object select
		
		objField.addElement(DomainConstants.SELECT_ID);
		objField.addElement("Name");
		objField.addElement("Material");
		objField.addElement("Dimensions");
		objField.addElement("Weight");
	
		//temp query bus "Change Action" * * select id;
	MapList objList = DomainObject.findObjects(context, "RLRDTyre", null, null, objField);
		System.out.println("Maplist here"+objList.toString());
		
		return objList;
	}
	
}