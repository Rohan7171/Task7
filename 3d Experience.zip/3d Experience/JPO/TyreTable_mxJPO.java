import matrix.db.Context;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;

import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import matrix.util.StringList;


public class RLSfindobj_mxJPO {
	
	public RLSfindobj_mxJPO()throws Exception {
		
	}	
	
	public RLSfindobj_mxJPO(Context context)throws Exception {
		

	}
	
	public RLSfindobj_mxJPO(Context context, String[] args)throws Exception {
		
	
	}
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getPartDetails(Context context,String args[]) throws Exception
	{
	
		StringList objField = new StringList(1);                                                    //-->1
		
		objField.addElement(DomainConstants.SELECT_ID);
		objField.addElement("Name");
		objField.addElement("Material");
		objField.addElement("Dimensions");
		objField.addElement("Weight");
		
		MapList objList = DomainObject.findObjects(context, "RLRDTyre", null, null, objField);
		System.out.println("Maplist here" +objList.toString());
		return objList;
	}
	
        return null;


}