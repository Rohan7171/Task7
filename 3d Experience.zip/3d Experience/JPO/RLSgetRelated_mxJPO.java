import java.util.ArrayList;
import java.util.Iterator;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;

import java.util.Map;
import matrix.db.Context;
import matrix.util.StringList;


public class RLSgetRelated_mxJPO {
// 1  Change Analysis  to  Change Analysis  IA-0000002  -
// 1  Change Implementation  to  Change Order  CO-0000100  -
// 1  Technical Assignee  to  Person  admin_platform  -
// 1  Object Route  to  Route Template  template1  1
// 1  Object Route  to  Route  R-0000101


	public final String PARTREVISION = "Part Revision";
	public final String DESIGN = "Design Responsibility";
	public final String EBOM = "EBOM";
	
	public final String PARTMASTER = "Part Master";
	public final String COMPANY = "Company";
	public final String PART = "Part";
	
	

	public RLSgetRelated_mxJPO()throws Exception {
		
	}	
	
	public RLSgetRelated_mxJPO(Context context)throws Exception {
		

	}
	
	public RLSgetRelated_mxJPO(Context context, String[] args)throws Exception {
		
	
	}

	@com.matrixone.apps.framework.ui.ProgramCallable


	//GET STARTING BUSINESS OBJECT
	
	//expand bus "30005.59959.32029.45354";
	public MapList getrelated(Context context,String args[]) throws Exception
	{
		//creating obj. dom  for  change Request expand bus "30005.59959.32029.44888";
		DomainObject dom = new DomainObject("30005.59959.32030.10858");
        System.out.println("BusSelects here"+dom);
	try
	
	  {
	    String relPattern  = PARTREVISION + "," + DESIGN + "," + EBOM;
	 	
	    String typePattern = PARTMASTER + "," + COMPANY + "," + PART;
		
	    StringList busSelects = new StringList();
	     
		busSelects.add(DomainConstants.SELECT_ID);
		busSelects.add(DomainConstants.SELECT_TYPE);
		busSelects.add(DomainConstants.SELECT_CURRENT);
		busSelects.add(DomainConstants.SELECT_NAME);
		busSelects.add(DomainConstants.SELECT_VAULT);
		

        System.out.println("BusSelects here" +busSelects);
		
		MapList mpList = dom.getRelatedObjects(context,   //context user.
	                                     relPattern,      //relationship attached to bus.
	                                     typePattern,     //type of relationship.
	                                     busSelects,      //fetching bus details.
										 busSelects, 
	                                     true,
	                                     true,
	                                     (short)1,
	                                     "",
	                                     "",
	                                     0);
				

		System.out.println("list------------------->"+mpList);

	
	
	  Iterator it = mpList.iterator();
	
		 while(it.hasNext())
	         {
				Map map = (Map)it.next();
				System.out.println(map);
	         }
		
	}
	
	catch(Exception e)	
	 {    
		
		System.out.println(e);
		System.out.println(".>>>>>error here>>>>>>>>");
	
	 }
	
	
   return null;
	 
	
	}
	
	}


