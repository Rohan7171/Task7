import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import matrix.db.Context;
import matrix.util.StringList;


public class ChangeOrderBaseDemo_mxJPO {
	
	public ChangeOrderBaseDemo_mxJPO()throws Exception {
		
	}	
	
	public ChangeOrderBaseDemo_mxJPO(Context context)throws Exception {
		

	}
	
	public ChangeOrderBaseDemo_mxJPO(Context context, String[] args)throws Exception {
		
	
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAllChangeActions(Context context,String args[]) throws Exception
	{
	
		StringList objSelects = new StringList(1); // object select
		 
		objSelects.addElement(DomainConstants.SELECT_ID);
		objSelects.addElement(DomainConstants.SELECT_NAME);
		objSelects.addElement(DomainConstants.SELECT_TYPE);
		objSelects.addElement(DomainConstants.SELECT_CURRENT);
		
		objSelects.addElement(DomainObject.SELECT_ID);
		
		
		
		//temp query bus "Change Action" * * select id;
		MapList objList = DomainObject.findObjects(context, "Change Action", null, null, objSelects);
		System.out.println("Maplist here"+objList.toString());
		return objList;
	}
	

}

