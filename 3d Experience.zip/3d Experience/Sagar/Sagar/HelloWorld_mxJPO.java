import matrix.db.Context;

/*
 ** ${CLASS:emxDemoUtil}
 **
 ** Copyright (c) 2000-2022 Dassault Systemes. All Rights Reserved.
 */

 
 
 
 public class HelloWorld_mxJPO {
 

     public int mxMain (Context context, String[] args) throws Exception {
         System.out.println("Hello World!!");
         
         return  0;
     }
        
     }	
 