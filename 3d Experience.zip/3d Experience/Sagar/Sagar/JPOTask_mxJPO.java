import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Iterator;
import java.util.Map;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;

import matrix.db.Context;
import matrix.util.StringList;


public class JPOTask_mxJPO {
	
	public JPOTask_mxJPO()throws Exception {
		
	}	
	
	public JPOTask_mxJPO(Context context)throws Exception {
		

	}
	
	public JPOTask_mxJPO(Context context, String[] args)throws Exception {
		
	
	}
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAllDetails(Context context,String args[]) throws Exception
	{
	
		FileWriter errorFile   = new FileWriter("E:\\Ashwini\\err_report.txt"); 
		FileWriter outputFile  = new FileWriter("E:\\Ashwini\\output_report.txt"); 
		BufferedWriter buffer1 = new BufferedWriter(errorFile);
		BufferedWriter buffer2 = new BufferedWriter(outputFile); 		
    	     
			 
			 
		StringList objSelects = new StringList(1); // object select
		 
		objSelects.addElement(DomainObject.SELECT_TYPE);
		objSelects.addElement(DomainObject.SELECT_NAME);
		objSelects.addElement(DomainObject.SELECT_REVISION);
		objSelects.addElement(DomainObject.SELECT_ID);
		objSelects.addElement(DomainObject.SELECT_OWNER);
		objSelects.addElement(DomainObject.SELECT_ORIGINATED);
		objSelects.addElement("attribute[Weight].value");
		objSelects.addElement("attribute[UOM Type].value");
		objSelects.addElement("attribute[Current Version].value");
		
		
		
		
		//temp query bus "Change Action" * * select id;
		//MapList objList = DomainObject.findObjects(context, "Part", null, null, objSelects);
		String where= "originated >= '1/1/2022' && originated >= '3/1/2023' ";
		int limit =15;
		MapList objList = DomainObject.findObjects(context,
				"Part", 		// TYPE TO SEARCH
				null, 			// NAMEPATTERN
				null,			// revPattern
				null, 			// ownerPattern
				"*", 			// VaultPattern
				where, 			// whereExpression
				null, 			// queryName
				false,			// expandType //true, if the query should find subtypes of the given types
				objSelects,		// objectSelects
				(short)limit);	// objectLimit
				
				
				Iterator mapListItr = objList.iterator();
				 Map map =null;
				 while (mapListItr.hasNext())
				 {
						map = (Map) mapListItr.next();
						
					 String strPARTId     = (String) map.get(DomainObject.SELECT_ID);
					 String strPARTName   = (String) map.get(DomainObject.SELECT_NAME);
					 String strPARTType   = (String) map.get(DomainObject.SELECT_TYPE);
					 String strPARTRev    = (String) map.get(DomainObject.SELECT_REVISION);
					 String strPARTOwner  = (String) map.get(DomainObject.SELECT_OWNER);
					 String strPARTOrigin = (String) map.get(DomainObject.SELECT_ORIGINATED);
					 
					 // String relPattern = "Design Responsibility";
					 String relPattern = PropertyUtil.getSchemaProperty(context,
							  "relationship_DesignResponsibility");
					 
					  System.out.println(strPARTId);
					  
					 
					 
					 StringList busSelects = new StringList(1);
					 busSelects.add(DomainConstants.SELECT_NAME);
					 
					 
					 DomainObject dom = new DomainObject(strPARTId);
					 
					 int limit1 = 5;
					  MapList myList = dom.getRelatedObjects(context,   //context user.
                              relPattern,    //relationship attached to bus.
                              strPARTType,   //type of relationship.
                              busSelects,    //fetching bus details.
							  null, 
                              true,			//getTo
                              false,			//getFrom
                              (short)1,		//recurseToLevel
                              "",			//objectWhere
                              "",			//relationshipWhere
                              limit1);			//limit
							  
					
					// Map myList = dom.getRelatedObject(context, relPattern, false, busSelects,null);
				
					 
					 // System.out.println("HEY!!I AM HERE");
						
					// System.out.println("connected Object Names"+myList);
					 
					 
					 System.out.println("HEY!!I AM HERE"+myList);
						
						
					   Iterator it = myList.iterator();
					
						 while(it.hasNext())
					          {
								  System.out.println("HELLO");
								 Map map1 = (Map)it.next();
								 System.out.println("connected Object Names"+map1);
					          }
						
				 }
				
		 buffer2.write(objList.toString());
		 buffer2.close(); 
		// System.out.println("Maplist here"+objList.toString());
		 return objList;
	}
	

}

