import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import matrix.db.Context;
import matrix.util.StringList;
import java.util.HashMap;
import java.util.Map;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import com.matrixone.apps.domain.DomainRelationship;
import java.util.Iterator;
import com.dassault_systemes.enovia.e6wv2.foundation.db.MqlUtil;

public class RacketHandle_mxJPO {
	
	public RacketHandle_mxJPO()throws Exception {
		
	}	
	
	public RacketHandle_mxJPO(Context context)throws Exception {
		

	}
	
	
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAllRacketHandle(Context context,String args[]) throws Exception
	{
			
			  
			//paramMap->objectID--->RacketObjectId-->domainObject using RacketObjectId->dom.getRelated
			  
			  // System.out.println("START getAllRacketHandle");
              // Map programMap = (Map) JPO.unpackArgs(args);
			// MapList myList = null;
              // Map actionMap = new HashMap();
              // Map requestMap = (Map) programMap.get("requestMap");
              // Map paramMap = (Map)programMap.get("paramMap");
            
			  // System.out.println("requestMap>> "+requestMap);
			  // System.out.println("paramMap>> "+paramMap);
		
		     // String parentOID = (String) requestMap.get("objectId"); //-->TennisRacket
			 // System.out.println("parentOID"+parentOID);
			 
		     // StringList busSelects = new StringList(1);
		     // busSelects.add(DomainConstants.SELECT_NAME);
				// busSelects.add(DomainConstants.SELECT_ID);
					 
					// String relPattern = "HasAGrip";
					// String strPARTType ="GRP_01_TypeTennisGrip";
					
					// String parentOID = (String) requestMap.get("objectId"); //-->TennisRacket
         
				    // DomainObject dom = new DomainObject(parentOID);
					
				   
					 
					 
					// expand bus 30005.59959.27016.58156;
				    // 1  HasAGrip  to  GRP_01_TypeTennisGrip  Grip54  1 8
					 
					 
					 
					 // int limit1 = 5;
					  //  myList = dom.getRelatedObjects(context,   //context user.
                              // relPattern,    //relationship attached to bus.
                              // strPARTType,   //type of relationship.
                              // busSelects,    //fetching bus details.
							  // null, 
                              // true,			//getTo-->
                              // false,			//getFrom
                              // (short)1,		//recurseToLevel
                              // "",			//objectWhere
                              // "",			//relationshipWhere
                              // limit1);			//limit
					 // System.out.println("HEY!!I AM HERE"+myList);
						
						
					 // Iterator it = myList.iterator();
					    // Map map1;
						// while(it.hasNext())
					          // {
								  // System.out.println("HELLO");
								 // map1 = (Map)it.next();
								 // System.out.println("connected Object Names"+map1);
					          // }
		   // return myList;
		   
		   StringList objSelects = new StringList(1); // object select
		 
		objSelects.addElement(DomainConstants.SELECT_ID);
		objSelects.addElement(DomainConstants.SELECT_NAME);
		 
		objSelects.addElement("attribute[GRP_01_HandleMaterial].value");
		objSelects.addElement("attribute[GRP_01_Color].value");
		// objSelects.addElement(DomainObject.SELECT_ID);
		
		
		
		//temp query bus "GRP_01_TypeTennisGrip" * * select id;
		MapList objList = DomainObject.findObjects(context, "GRP_01_TypeTennisGrip", null, null, objSelects);
		System.out.println("Maplist here"+objList.toString());
		return objList;
		 
		
		
		
		
	}
	
	
	@com.matrixone.apps.framework.ui.PostProcessCallable
    public Map createGripPostProcess(Context context, String[] args) throws FrameworkException {
        try {
			System.out.println("START OF createGripPostProcess");
            Map programMap = (Map) JPO.unpackArgs(args);
            
            Map actionMap = new HashMap();
            Map requestMap = (Map) programMap.get("requestMap"); //parentOID
            Map paramMap = (Map)programMap.get("paramMap");
            
			System.out.println("requestMap>> "+requestMap);
			System.out.println("paramMap>> "+paramMap);
			
			
			
			
				String newObjectId = (String) paramMap.get("newObjectId"); //--->Grip
				String parentOID = (String) requestMap.get("objectId"); //-->TennisRacket
         
				DomainObject RacketObj = new DomainObject(parentOID);
				DomainObject GripObj = DomainObject.newInstance(context);
				GripObj.setId(newObjectId);
            
				DomainRelationship.connect(context, RacketObj, new RelationshipType("HasAGrip"),GripObj);
			 //    public static DomainRelationship connect(Context context, DomainObject fromObject, RelationshipType relationshipType, DomainObject toObject)

				System.out.println("Connected successfully>> ");

            
             // DomainRelationship.connect(context, parentOID, new RelationshipType("HasAGrip"),newObjectId);
            // department.promote(context);
            // department.setAttributeValue(context, attrOrganizationName, deptName);
			System.out.println("END OF createGripPostProcess");
            return actionMap;
            
        } catch (Exception e) {
            throw new FrameworkException(e);
        }
    }

public int IsGripConnected(Context context, String[] args) throws Exception 
{
	System.out.println("Start IsGripConnected \n\n");
	 int iRet = 1;
	final String HAS_A_GRIP_ID = "from[HasAGrip].to.id" ;
	final String MQL_QUERRY  = "print bus $1 select $2 dump";
	final String strObjectId = args[0]; //RacketID;
	//final String strFROMNAME = args[2];
	// final String strTotype = args[3];
	// final String toObjectId = args[4];
	// final String fromObjectId = args[5];
	
	
		     System.out.println("strobjectID"+strObjectId);
			// System.out.println("strFROMNAME"+strFROMNAME);
		    // System.out.println("strTotype"+strTotype);
			// System.out.println("fromObjectId"+fromObjectId);
	
			// System.out.println("toobjectID"+toObjectId);
	
	       String strGripID = "";
		  
		  try {
	      
		  strGripID = MqlUtil.mqlCommand(context, MQL_QUERRY, strObjectId, HAS_A_GRIP_ID);
		  System.out.println("gripID"+strGripID);
		  if ( !strGripID.isEmpty()){
		 
			 iRet = 0;
			 System.out.println(" Found");
		 
		   }
		 
		 
		  }
          catch (Exception e)
		  {
			System.out.println("Exception Found"); 
			e.printStackTrace();
		  }
		  
		 System.out.println("End IsGripConnected \n\n"); 
		  System.out.println("iRet is"+iRet);
		  return iRet;
}
}

