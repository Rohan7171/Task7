public int ChangeRequireSandDValuePS(Context context, String[] args) throws Exception
     {
         int iRet = 0;
        System.out.println("\n\nStart ChangeRequireSandDValuePS");

        final String PROJECT_SPACE_ID            = "to[HasAGrip].from.id";
        final String MQL_QUERRY                  = "print bus $1 select $2 dump";
        final String strObjectId                 = args[0]; //racketID
              String strProjectSpaceID           = "";
        try 
        {


            //GET 'PROJECT SPACE' ID FROM 'TECHNICAL STUDY'
            strProjectSpaceID = MqlUtil.mqlCommand(context, MQL_QUERRY, strObjectId, PROJECT_SPACE_ID);
            if ( !strProjectSpaceID.isEmpty())
            {
                iRet=1;
                System.out.println(" not found!");

            }
        }
        catch (Exception e)
        {
            System.out.println("Exception caught");
            e.printStackTrace();
        }
        System.out.println("End ChangeRequireSandDValuePS \n\n");
        return iRet;
    }