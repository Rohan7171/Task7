import matrix.db.Context;
import java.io.*;  
/*
 ** ${CLASS:emxDemoUtil}
 **
 ** Copyright (c) 2000-2022 Dassault Systemes. All Rights Reserved.
 */

 
 
 
 public class file_mxJPO {
 

     public int mxMain (Context context, String[] args) throws Exception {
    	 
    	  
    	  
    	     FileWriter writer = new FileWriter("E://Ashwini//testout.txt"); 
				BufferedWriter buffer = new BufferedWriter(writer);  
    	     buffer.write("Welcome in Ashwini's Folder12345678!!"); 
			 
			  
    	      // FileReader writer = new FileReader("E:\\Ashwini\\testout.txt"); 
				//BufferedReader buffer = new BufferedReader(writer);
				
				// String line;
				//while ((line = buffer.readLine()) != null) {
                //System.out.println(line);
              //}
			 // String line = buffer.readLine();
			  //System.out.println(line);
		
				
    	     buffer.close();  
    	     System.out.println("Success");  
    	      
    	  return 0;
        
     }	
 }
 
 
 