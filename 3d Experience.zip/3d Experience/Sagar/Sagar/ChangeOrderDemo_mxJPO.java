public class ChangeOrderDemo_mxJPO extends ChangeOrderBaseDemo_mxJPO{
	
	public ChangeOrderDemo_mxJPO()throws Exception {
	
}

public ChangeOrderDemo_mxJPO(Context context)throws Exception {

	super(context);
	
}
	
public ChangeOrderDemo_mxJPO(Context context, String[] args)throws Exception {
	
	
}
