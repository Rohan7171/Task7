
	import java.util.ArrayList;
	import java.util.Iterator;

	import com.matrixone.apps.domain.DomainConstants;
	import com.matrixone.apps.domain.DomainObject;
	import com.matrixone.apps.domain.util.MapList;

	import java.util.Map;
	import matrix.db.Context;
	import matrix.util.StringList;


	public class mygetInfo_mxJPO {

		public mygetInfo_mxJPO()throws Exception {
			
		}	
		
		public mygetInfo_mxJPO(Context context)throws Exception {
			

		}
		
		public mygetInfo_mxJPO(Context context, String[] args)throws Exception {
			
		
		}
		
	
		
		@com.matrixone.apps.framework.ui.ProgramCallable


		public MapList getmyInfo(Context context,String args[]) throws Exception
		{
			//creating obj. dom  for  change Request expand bus "30005.59959.32029.44888";
//			print bus 30005.59959.32029.44888 select id;
//			business object  Change Request CR-0000101 -
//			    id = 30005.59959.32029.44888
			DomainObject dom = new DomainObject("30005.59959.32029.44888");
			

	        
		try
		
		  {
			 
		    StringList busSelects = new StringList();
		     
			
			busSelects.add(DomainConstants.SELECT_TYPE);
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(DomainConstants.SELECT_REVISION);
			busSelects.add(DomainConstants.SELECT_VAULT);
			busSelects.add(DomainConstants.SELECT_OWNER);
			
			
			//MapList locMaplist = getInfo(context, busSelects);
			//MapList locMaplist = (MapList) dom.getInfo(context,busSelects
			Map locMap = dom.getInfo(context, busSelects);
	        System.out.println("BusSelects here--->" +busSelects);


					System.out.println("HEY there!!"+locMap);

		
		
		  
		}
		
		catch(Exception e)	
		 {    
			
			System.out.println(e);
			System.out.println("error here");
		
		 }
		
		
	   return null;
		 
		
		}
		
}



	

