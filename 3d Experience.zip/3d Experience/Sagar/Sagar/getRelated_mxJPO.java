import java.util.ArrayList;
import java.util.Iterator;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;

import java.util.Map;
import matrix.db.Context;
import matrix.util.StringList;


public class getRelated_mxJPO {
// 1  Change Analysis  to  Change Analysis  IA-0000002  -
// 1  Change Implementation  to  Change Order  CO-0000100  -
// 1  Technical Assignee  to  Person  admin_platform  -
// 1  Object Route  to  Route Template  template1  1
// 1  Object Route  to  Route  R-0000101
	public final String CHANGEACTION = "Change Analysis";
	public final String OBJECTROUTE = "Object Route";
	public final String CHANGE12="Technical Assignee";
	public final String CHANGEIMPLEMENTATION = "Change Implementation";
	
	public final String CHANGEREQUEST = "Change Analysis";
	public final String ROUTETEMPLATE = "Change Order";
	public final String ROUTE = "Route";
	public final String CHNAGEREQUEST = "Person";
	public final String CHNAGERE12="Route Template ";
	

	public getRelated_mxJPO()throws Exception {
		
	}	
	
	public getRelated_mxJPO(Context context)throws Exception {
		

	}
	
	public getRelated_mxJPO(Context context, String[] args)throws Exception {
		
	
	}
	
	
		
	
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
//	public MapList getAllChangeActions(Context context,String args[]) throws Exception
//	{
//	
//		StringList objSelects = new StringList(1); // object select
//		 
//		objSelects.addElement(DomainConstants.SELECT_ID);
//		objSelects.addElement("name");
//		objSelects.addElement("type");
//		objSelects.addElement("current");
//		
//		
//		//temp query bus "Change Action" * * select id;
//		MapList objList = DomainObject.findObjects(context, "Change Action", null, null, objSelects);
//		System.out.println("Maplist here"+objList.toString());
//		return objList;



//	}
	
	
	
	

	
	
//////////////////////////////-----//----------///---------//--------------------//////////////////////////////////////////
	
	
	
	
	
	//GET STARTING BUSINESS OBJECT
	
	//expand bus "30005.59959.32029.45354";
	public MapList getrelated(Context context,String args[]) throws Exception
	{
		//creating obj. dom  for  change Request expand bus "30005.59959.32029.44888";
		DomainObject dom = new DomainObject("30005.59959.32029.44888");
        System.out.println("BusSelects here"+dom);
	try
	
	  {
		 
		
	    String relPattern  = CHANGEACTION + "," + OBJECTROUTE + "," + CHANGEIMPLEMENTATION + "," +CHANGE12;
	    // String typePattern = CHANGEACTION + ROUTETEMPLATE + ROUTE + CHANGEREQUEST;
		
	
	    String typePattern = CHANGEREQUEST + "," + ROUTETEMPLATE + "," + ROUTE + "," + CHANGEREQUEST + "," + CHNAGERE12;
		
	    StringList busSelects = new StringList();
	     
		busSelects.add(DomainConstants.SELECT_ID);
		busSelects.add(DomainConstants.SELECT_TYPE);
		busSelects.add(DomainConstants.SELECT_CURRENT);
		busSelects.add(DomainConstants.SELECT_NAME);
		busSelects.add(DomainConstants.SELECT_VAULT);
		

        System.out.println("BusSelects here" +busSelects);
		
		MapList mpList = dom.getRelatedObjects(context,   //context user.
	                                     relPattern,      //relationship attached to bus.
	                                     typePattern,     //type of relationship.
	                                     busSelects,      //fetching bus details.
										 busSelects, 
	                                     true,
	                                     true,
	                                     (short)1,
	                                     "",
	                                     "",
	                                     0);
				

				System.out.println("list------------------->"+mpList);

	
	
	  Iterator it = mpList.iterator();
	
		 while(it.hasNext())
	         {
				Map map = (Map)it.next();
				System.out.println(map);
	         }
		
	}
	
	catch(Exception e)	
	 {    
		
		System.out.println(e);
		System.out.println(".>>>>>error here>>>>>>>>");
	
	 }
	
	
   return null;
	 
	
	}
	
	}


