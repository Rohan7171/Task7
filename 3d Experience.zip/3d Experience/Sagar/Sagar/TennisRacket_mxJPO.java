import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import matrix.db.Context;
import matrix.util.StringList;


public class TennisRacket_mxJPO {
	
	public TennisRacket_mxJPO()throws Exception {
		
	}	
	
	public TennisRacket_mxJPO(Context context)throws Exception {
		

	}
	
	
	
	
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getAllTennisRacket(Context context,String args[]) throws Exception
	{
		System.out.println("START getAllTennisRacket");
		StringList objSelects = new StringList(1); // object select
		 
		
		 objSelects.addElement(DomainConstants.SELECT_ID);
		// objSelects.addElement(DomainConstants.SELECT_TYPE);
		// objSelects.addElement(DomainConstants.SELECT_NAME);
		// objSelects.addElement(DomainObject.SELECT_REVISION);
		 objSelects.addElement("attribute[GRP_01_Material].value");
		 objSelects.addElement("attribute[GRP_01_Cost].value");
		 objSelects.addElement("attribute[GRP_01_Manfctat].value");
		 objSelects.addElement("attribute[GRP_01_DoM].value");
		 objSelects.addElement("attribute[GRP_01_Sizes].value");
		
		
		
		
		
		//temp query bus "GRP_01_TypeTennisRacket" * * select id;
		MapList objList = DomainObject.findObjects(context, "TennisRacket", null, null, objSelects);
		System.out.println("Racket details are as follows------->"+objList.toString());
		return objList;
	}
	

}

